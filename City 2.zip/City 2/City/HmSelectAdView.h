//
//  HmSelectAdView.h
//  City
//
//  Created by Mr.Lin on 2020/5/6.
//  Copyright © 2020 Mr.Lin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HmSelectAdView : UIView

@property (nonatomic, copy) void (^confirmSelect)(NSArray *address);
- (instancetype)initWithLastContent:(NSArray *)lastContent;
- (void)show;

@end

NS_ASSUME_NONNULL_END
