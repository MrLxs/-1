//
//  HmAddressModel.m
//  City
//
//  Created by Mr.Lin on 2020/5/6.
//  Copyright © 2020 Mr.Lin. All rights reserved.
//

#import "HmAddressModel.h"

@implementation HmAddressModel

@end
