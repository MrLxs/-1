//
//  UIView+Extension.h
//  City
//
//  Created by Mr.Lin on 2020/5/6.
//  Copyright © 2020 Mr.Lin. All rights reserved.
//

#import <UIKit/UIKit.h>

#define vAlertTag 10086

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Extension)

@property (nonatomic, assign) CGFloat hm_x;
@property (nonatomic, assign) CGFloat hm_y;
@property (nonatomic, assign) CGFloat hm_centerX;
@property (nonatomic, assign) CGFloat hm_centerY;
@property (nonatomic, assign) CGFloat hm_width;
@property (nonatomic, assign) CGFloat hm_height;
@property (nonatomic, assign) CGSize hm_size;
@property (nonatomic, assign) CGPoint hm_origin;

@property (nonatomic, assign) CGFloat hm_bottom;
@property (nonatomic, assign) CGFloat hm_right;

//获取当前视图的Controller;
@property (nonatomic, readonly) UIViewController *hm_viewController;

@end

NS_ASSUME_NONNULL_END
