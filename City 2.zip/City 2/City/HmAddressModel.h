//
//  HmAddressModel.h
//  City
//
//  Created by Mr.Lin on 2020/5/6.
//  Copyright © 2020 Mr.Lin. All rights reserved.
//

#import <JSONModel/JSONModel.h>
#import "HmAddressCityModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface HmAddressModel : JSONModel

@property (nonatomic, strong) NSString<Optional> *name;
@property (nonatomic, strong) NSArray<HmAddressCityModel, Optional> *city;

@end

NS_ASSUME_NONNULL_END
