//
//  HmAddressCityModel.h
//  City
//
//  Created by Mr.Lin on 2020/5/6.
//  Copyright © 2020 Mr.Lin. All rights reserved.
//

#import <JSONModel/JSONModel.h>

@protocol HmAddressCityModel <NSObject>

@end

NS_ASSUME_NONNULL_BEGIN


@interface HmAddressCityModel : JSONModel

@property (nonatomic, strong) NSString<Optional> *name;
@property (nonatomic, strong) NSArray<Optional> *area;

@end

NS_ASSUME_NONNULL_END
